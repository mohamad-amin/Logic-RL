# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from collections import defaultdict

import torch

from verl import DataProto
from verl.utils.reward_score import _default_compute_score


class NaiveRewardManager:
    """The reward manager."""

    def __init__(
        self,
        tokenizer,
        num_examine: int | None = None,
        compute_score=None,
        reward_fn_key="data_source",
        **reward_kwargs,
    ) -> None:
        self.tokenizer = tokenizer
        # Default to 0 (no verbose printing) if not provided
        self.num_examine = 0 if num_examine is None else num_examine
        self.compute_score = compute_score or _default_compute_score
        self.reward_fn_key = reward_fn_key
        self.reward_kwargs = reward_kwargs

    def __call__(self, data: DataProto, return_dict=False):
        """We will expand this function gradually based on the available datasets"""

        # If there is rm score, we directly return rm score. Otherwise, we compute via rm_score_fn
        if "rm_scores" in data.batch.keys():
            if return_dict:
                # Ensure 'score' key exists if only rm_scores are present
                # This might need adjustment depending on how rm_scores are structured
                reward_extra_info = defaultdict(list)
                # Assuming rm_scores is (batch_size, seq_len) and reward is at the end
                scores = data.batch["rm_scores"][:, -1].tolist()
                reward_extra_info['score'].extend(scores)
                # Placeholder for prompt/response if only rm_scores are available
                # This logic might need refinement based on actual use case
                prompt_strings = ["N/A (RM Score)"] * len(scores)
                response_strings = ["N/A (RM Score)"] * len(scores)
                return {
                    "reward_tensor": data.batch["rm_scores"],
                    "reward_extra_info": reward_extra_info,
                    "prompt_strings": prompt_strings,
                    "response_strings": response_strings,
                }
            else:
                return data.batch["rm_scores"]

        reward_tensor = torch.zeros_like(data.batch["responses"], dtype=torch.float32)
        reward_extra_info = defaultdict(list)
        prompt_strings = []  # New list for prompts
        response_strings = [] # New list for responses

        already_print_data_sources = {}

        for i in range(len(data)):
            data_item = data[i]  # DataProtoItem

            prompt_ids = data_item.batch["prompts"]

            prompt_length = prompt_ids.shape[-1]

            valid_prompt_length = data_item.batch["attention_mask"][:prompt_length].sum()
            valid_prompt_ids = prompt_ids[-valid_prompt_length:]

            response_ids = data_item.batch["responses"]
            valid_response_length = data_item.batch["attention_mask"][prompt_length:].sum()
            valid_response_ids = response_ids[:valid_response_length]

            # decode
            prompt_str = self.tokenizer.decode(valid_prompt_ids, skip_special_tokens=True)
            response_str = self.tokenizer.decode(valid_response_ids, skip_special_tokens=True)

            sequences = torch.cat((valid_prompt_ids, valid_response_ids))
            sequences_str = self.tokenizer.decode(sequences)

            ground_truth = data_item.non_tensor_batch["reward_model"]["ground_truth"]

            data_source = data_item.non_tensor_batch[self.reward_fn_key]

            extra_info = data_item.non_tensor_batch.get("extra_info", None)

            # Call compute_score
            computed_score_result = self.compute_score(
                data_source=data_source,
                solution_tokens=sequences,
                solution_str=sequences_str,
                ground_truth=ground_truth,
                extra_info=extra_info,
                **self.reward_kwargs,
            )

            # Handle dict or float return type
            if isinstance(computed_score_result, dict):
                reward = computed_score_result.get("score", 0.0) # Default to 0 if 'score' key missing
                # Store the information including original reward
                for key, value in computed_score_result.items():
                    reward_extra_info[key].append(value)
                # Ensure 'score' key is present even if extracted from dict
                # This is already handled by the loop above if 'score' is in computed_score_result
            else:
                # This case should ideally not be reached if compute_score always returns a dict
                print("[Warning] compute_score did not return a dictionary as expected.")
                reward = float(computed_score_result) # Ensure it's float
                reward_extra_info['score'].append(reward)

            reward_tensor[i, valid_response_length - 1] = reward
            prompt_strings.append(prompt_str) # Store prompt
            response_strings.append(response_str) # Store response

            if data_source not in already_print_data_sources:
                already_print_data_sources[data_source] = 0

            if already_print_data_sources[data_source] < self.num_examine:
                already_print_data_sources[data_source] += 1
                print("[prompt]", prompt_str)
                print("[response]", response_str)
                print("[ground_truth]", ground_truth)
                # Print based on the original return type
                if isinstance(computed_score_result, dict):
                    for key, value in computed_score_result.items():
                        print(f"[{key}]", value)
                else:
                    print("[score]", computed_score_result)

        if return_dict:
            return {
                "reward_tensor": reward_tensor,
                "reward_extra_info": reward_extra_info,
                "prompt_strings": prompt_strings,      # Add prompts
                "response_strings": response_strings,   # Add responses
            }
        else:
            return reward_tensor
