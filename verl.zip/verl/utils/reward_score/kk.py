import re
import torch
import collections
from enum import Enum
from typing import Dict, Tuple, Optional
import math # For math.pi and math.cos if not using torch's versions for scalar math


def check_for_repetition_rolling_hash_torch(
    token_ids: torch.Tensor,
    ngram_n: int = 35,
    threshold: int = 2
) -> tuple[bool, str]:
    """
    Checks a tensor of token IDs for n-gram repetitions using a rolling hash.

    Args:
        token_ids: A 1D torch.Tensor of integer token IDs (e.g., LongTensor).
        ngram_n: The size of the n-gram sequence to check.
        threshold: The minimum number of times an n-gram hash must repeat to trigger penalty.

    Returns:
        A tuple: (bool indicating if excessive repetition was found, description string).
    """
    if not isinstance(token_ids, torch.Tensor) or token_ids.dim() != 1:
        return False, "Input must be a 1D torch.Tensor"

    tensor_len = token_ids.size(0)

    if tensor_len < ngram_n or ngram_n <= 0:
        return False, f"Tensor too short ({tensor_len}) for n-gram size {ngram_n} or invalid n-gram size."

    if token_ids.dtype not in [torch.long, torch.int, torch.int32, torch.int64]:
        try:
            token_ids = token_ids.long()
            print(f"Warning: Input tensor dtype was {token_ids.dtype}, converted to long.")
        except Exception as e:
            return False, f"Tensor dtype ({token_ids.dtype}) not suitable for hashing: {e}"

    BASE = 257  # Prime base (or another suitable prime)
    MOD = 10**9 + 7 # Large prime modulus

    try:
        power_base_n_minus_1 = pow(BASE, ngram_n - 1, MOD)
    except ValueError:
         return False, "Cannot compute power for n-gram size <= 1"


    hash_counts = collections.defaultdict(int)
    current_hash = 0

    try:
        initial_ngram_ids = token_ids[:ngram_n]
        for i in range(ngram_n):
            token_id_val = initial_ngram_ids[i].item()
            current_hash = (current_hash * BASE + token_id_val) % MOD
    except IndexError:
         return False, "Index error during initial hash calculation."
    except Exception as e:
        return False, f"Error processing initial token IDs: {e}"


    hash_counts[current_hash] += 1
    found_repetition = False
    description = "No repetitions found meeting criteria."
    max_hash_val = current_hash

    for i in range(ngram_n, tensor_len):
        try:
            old_token_id_val = token_ids[i - ngram_n].item()
            new_token_id_val = token_ids[i].item()
        except IndexError:
             return False, f"Index error during rolling hash at index {i}."
        except Exception as e:
            return False, f"Error processing token IDs at index {i}: {e}"


        leading_term_hash = (old_token_id_val * power_base_n_minus_1) % MOD
        current_hash = (current_hash - leading_term_hash + MOD) % MOD

        current_hash = (current_hash * BASE + new_token_id_val) % MOD

        hash_counts[current_hash] += 1
        count = hash_counts[current_hash]

        if count >= threshold:
            found_repetition = True
            max_hash_val = current_hash
            description = f"Repetition detected: An N-gram hash ({max_hash_val}) repeated {count} times (threshold={threshold}, n={ngram_n})."
            break

    if not found_repetition:
        max_found_count = 0
        if hash_counts:
            max_found_count = max(hash_counts.values())
        if max_found_count > 1:
             description = f"No n-gram (n={ngram_n}) repeated {threshold} or more times (max hash count was {max_found_count})."
        else:
             description = f"No n-gram (n={ngram_n}) repeated at all."

    return found_repetition, description


class ModelResponse(Enum):
    I_DONT_KNOW = "I don't know"


def extract_solution(solution_str: str) -> Tuple[Optional[str], str]:
    """Extracts the final answer from the model's response string.
    
    Args:
        solution_str: Raw response string from the language model
        
    Returns:
        Tuple containing (extracted_answer, processed_string)
    """
    # Split response to isolate assistant output
    if "Assistant:" in solution_str:
        processed_str = solution_str.split("Assistant:", 1)[1]
    elif "<|im_start|>assistant" in solution_str:
        processed_str = solution_str.split("<|im_start|>assistant", 1)[1]
    else:
        print("[Error] Failed to locate model response header")
        return None, solution_str

    # Extract final answer using XML-style tags
    answer_pattern = r'<answer>(.*?)</answer>'
    matches = list(re.finditer(answer_pattern, processed_str, re.DOTALL))
    
    if not matches:
        print("[Error] No valid answer tags found")
        return None, processed_str
        
    final_answer = matches[-1].group(1).strip()
    return final_answer, processed_str

def parse_solution_text_format(solution_text: str) -> Dict[str, str]:
    """Parses ground truth solution text into status dictionary.
    
    Args:
        solution_text: Formatted solution text from dataset
        
    Returns:
        Dictionary mapping character names to their roles (knight/knave)
    """
    status_dict = {}
    print("\n[Ground Truth Parsing]")
    
    for line in solution_text.split('\n'):
        line = line.strip()
        if not line:
            continue
            
        match = re.search(r'\b([A-Za-z]+)\b.*?\b(knight|knave)\b', line, re.IGNORECASE)
        if match:
            name, role = match.groups()
            status_dict[name] = role.lower()
            print(f"  Found: {name} → {role}")
        else:
            print(f"  [Warning] Unparseable line: '{line}'")
    
    return status_dict

def parse_model_answer(answer_text: str, expected_names: list) -> Optional[Dict[str, str]]:
    """Parses model's answer text into status dictionary.
    
    Args:
        answer_text: Text extracted from model's <answer> tags
        expected_names: List of character names requiring identification
        
    Returns:
        Dictionary mapping character names to predicted roles, or None if incomplete
    """
    status_dict = {}
    print("\n[Model Answer Parsing]")
    print(f"  Expected characters: {expected_names}")

    if answer_text == "I don't know":
        return ModelResponse.I_DONT_KNOW

    knight_count = answer_text.lower().count('knight')
    knave_count = answer_text.lower().count('knave')

    print(f"  Number of predicted roles: {knight_count + knave_count}")
    if knight_count + knave_count != len(expected_names):
        print(f"  [Error] Number of characters mismatch: {knight_count + knave_count} != {len(expected_names)}")
        return None

    for name in expected_names:
        pattern = re.compile(
            rf'\b{re.escape(name)}\b\s+is\s+a\s+\b(knight|knave)\b', 
            re.IGNORECASE
        )
        match = pattern.search(answer_text)
        
        if match:
            role = match.group(1).lower()
            status_dict[name] = role
            print(f"  Found: {name} → {role}")
        else:
            print(f"  [Error] Missing identification for {name}")
            return None
    
    return status_dict

def validate_response_structure(processed_str: str) -> bool:
    """Performs comprehensive validation of response structure.
    
    Args:
        processed_str: Processed response string from the model
        
    Returns:
        Boolean indicating whether all formatting requirements are met
    """
    print("\n[Structure Validation]")
    validation_passed = True

    # Check required tags
    tags = {
        'think_start': ('<think>', 1),
        'think_end': ('</think>', 1),
        'answer_start': ('<answer>', 1),
        'answer_end': ('</answer>', 1)
    }

    positions = {}
    for tag_name, (tag_str, expected_count) in tags.items():
        count = processed_str.count(tag_str)
        positions[tag_name] = pos = processed_str.find(tag_str)
        
        print(f"  {tag_str}: count={count}, position={pos}")
        
        if count != expected_count:
            print(f"  [Error] {tag_str} appears {count} times (expected {expected_count})")
            validation_passed = False

    # Verify tag order
    if (positions['think_start'] > positions['think_end'] or
        positions['think_end'] > positions['answer_start'] or
        positions['answer_start'] > positions['answer_end']):
        print("  [Error] Incorrect tag order: Expected <think>...</think><answer>...</answer>")
        validation_passed = False
    else:
        print("  Tag sequence validation passed")

    return validation_passed

def compute_score(data_source: str,
                 solution_tokens: torch.Tensor,
                 solution_str: str,
                 ground_truth: Dict[str, str],
                 extra_info: Dict[str, str],
                 format_reward: int = 0.5, 
                 answer_reward: float = 1.0,
                 hesitation_reward: float = 0.0,
                 partial_answer_reward: float = 0.25,
                 wrong_answer_reward: float = 0.0,
                 repetition_reward: float = -0.5,
                 repetition_min_length: int = 75,
                 length_penalty_threshold: int = 1500,
                 length_penalty_factor: float = 10.0, # Steepness for sigmoid (UNUSED for cosine decay)
                 min_overall_penalty_factor: float = 1.0 # Min factor for (Format+Answer) at max length
                #  min_overall_penalty_factor: float = 1.0 # Min factor for (Format+Answer) at max length
                 ) :
    """Computes comprehensive score for model response.
    
    Args:
        data_source: Data source name
        solution_tokens: Encoded solution tokens from the model.
        solution_str: Raw model response string
        ground_truth: Dictionary containing ground truth data
        format_reward: Points for correct format.
        answer_reward: Points for correct answer.
        hesitation_reward: Points for "I don't know" if correct format.
        partial_answer_reward: Points for partially correct answer if correct format.
        wrong_answer_reward: Points for wrong answer if correct format.
        repetition_reward: Penalty for repetition (currently not integrated into total score).
        repetition_min_length: Min length for repetition check.
        length_penalty_threshold: Token count threshold after which length penalty starts.
        length_penalty_factor: Steepness 's' for the sigmoid length penalty curve (UNUSED for cosine decay).
        min_overall_penalty_factor: The minimum overall multiplicative factor that (Format+Answer) score can be reduced to due to length.
        
    Returns:
        Dict with score components.
    """
    print("\n" + "="*80)
    print(" Processing New Sample ".center(80, '='))

    # Parse ground truth data
    solution_text = ground_truth.get('solution_text_format', '')
    gt_status = parse_solution_text_format(solution_text)
    expected_names = list(gt_status.keys())
    print(f"[Ground Truth] Final identities: {gt_status}")

    # Extract model answer
    answer_text, processed_str = extract_solution(solution_str)
    print(f"\n[Model Response]\n{processed_str}")

    # Validate response structure
    format_correct = validate_response_structure(processed_str)
    format_score = format_reward if format_correct else 0
    print(f"\n  Format validation: {'PASS' if format_correct else 'FAIL'}")
    print(f"  Format score: {format_score}")

    # ----------------------------------------------------------------------
    # Validate answer content and compute boolean flags for downstream use
    # ----------------------------------------------------------------------
    answer_score = 0
    # Initialize boolean flags
    is_format_correct = format_correct
    is_hesitation = False
    is_correct_answer = False
    is_wrong_answer = False
    is_partially_wrong_answer = False

    if format_correct and answer_text:
        pred_status = parse_model_answer(answer_text, expected_names)
        if pred_status == ModelResponse.I_DONT_KNOW:
            answer_score = hesitation_reward
            is_hesitation = True
        elif pred_status:
            print(f"\n[Content Validation]")
            print(f"  Expected: {gt_status}")
            print(f"  Predicted: {pred_status}")
            if pred_status == gt_status:
                answer_score = answer_reward
                is_correct_answer = True
            else:
                answer_score = partial_answer_reward
                is_partially_wrong_answer = True
        else:
            answer_score = wrong_answer_reward
            is_wrong_answer = True
    else:
        answer_score = wrong_answer_reward
        is_wrong_answer = True

    # Calculate length penalty
    response_length = len(solution_tokens)
    print(f"\n[Length Analysis]")
    print(f"  Response length: {response_length} tokens")
    
    p_overall = 1.0 # Default for lengths at or below threshold
    p_cos_1_to_0_factor = 1.0 # Represents the (1+cos)/2 part, defaults to 1 (no decay component)

    if response_length > length_penalty_threshold:
        # Max length for decay scaling
        L_max_decay = 6000.0 

        if response_length >= L_max_decay:
            # Length is at or beyond the max, so cosine component is fully decayed (0)
            p_cos_1_to_0_factor = 0.0
            print(f"  Length at/beyond max ({L_max_decay}), cosine factor is 0.0")
        else:
            # Length is between threshold and L_max_decay
            x_norm_float = (float(response_length) - length_penalty_threshold) / (L_max_decay - length_penalty_threshold)
            # x_norm_float is in [0, 1) here
            
            # Cosine decay using only the first pi/2 cycle: cos( (pi/2) * x_norm )
            # This goes from 1 (at x_norm=0) to 0 (at x_norm=1)
            # The decay is slower initially compared to a full pi cycle in (1+cos(pi*x))/2
            p_cos_1_to_0_tensor = torch.cos(torch.tensor( (math.pi / 2.0) * x_norm_float, dtype=torch.float32))
            p_cos_1_to_0_factor = torch.clamp(p_cos_1_to_0_tensor, 0.0, 1.0).item() # Clamp to handle potential float precision issues at boundaries
            print(f"  Normalized length (x_norm): {x_norm_float:.4f}")
            print(f"  Cosine decay component (1 to 0 factor, pi/2 cycle): {p_cos_1_to_0_factor:.4f}")

        p_overall = min_overall_penalty_factor + (1.0 - min_overall_penalty_factor) * p_cos_1_to_0_factor
        print(f"  Calculated overall penalty factor (P_overall): {p_overall:.4f}")
    else:
        print(f"  Length within threshold ({length_penalty_threshold}), no penalty applied (P_overall=1.0)")
    
    current_raw_score = format_score + answer_score
    total_score = current_raw_score * p_overall

    print("\n" + "-"*80)
    print(f" Final Score Calculation ".center(80, '-'))
    print(f"  Format Component (S_F): {format_score}")
    print(f"  Answer Component (S_A): {answer_score}")
    print(f"  Raw Score (S_F + S_A): {current_raw_score}")
    print(f"  Cosine Decay Component (P_cos_1_to_0): {p_cos_1_to_0_factor:.4f}") # New print
    print(f"  Min Overall Penalty Factor (Config): {min_overall_penalty_factor}")
    print(f"  Calculated Overall Penalty (P_overall): {p_overall:.4f}")
    print(f"  Final Score ((S_F+S_A) * P_overall): {total_score:.4f}")
    print("="*80 + "\n")

    return {
        "score": total_score, # This is the final score for RL
        "pre_penalty_score": current_raw_score, # Original sum before any length consideration
        "format_score_component": format_score,
        "answer_score_component": answer_score,
        "length_penalty_cosine_1_to_0_factor": p_cos_1_to_0_factor, # The (1+cos)/2 part
        "overall_length_penalty_factor_applied": p_overall, # This is P_overall (factor applied to raw score)
        "raw_response_str": processed_str,
        "parsed_answer_text": answer_text, # Potentially useful
        "gt_status": gt_status,
        "pred_status": pred_status if format_correct and answer_text else None,
        # Boolean flags for downstream metric computation
        "is_format_correct": is_format_correct,
        "is_hesitation": is_hesitation,
        "is_correct_answer": is_correct_answer,
        "is_wrong_answer": is_wrong_answer,
        "is_partially_wrong_answer": is_partially_wrong_answer,
    }
